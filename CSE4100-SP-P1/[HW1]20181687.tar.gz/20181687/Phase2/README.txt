project 1 baseline

myshell.h
      header file

myshell.c
       source file

gcc myshell.c -o myshell -> compile
./myshell -> execute


