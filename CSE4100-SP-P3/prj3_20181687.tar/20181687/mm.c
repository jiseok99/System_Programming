/*
 * mm-naive.c - The fastest, least memory-efficient malloc package.
 * 
 * In this naive approach, a block is allocated by simply incrementing
 * the brk pointer.  A block is pure payload. There are no headers or
 * footers.  Blocks are never coalesced or reused. Realloc is
 * implemented directly using mm_malloc and mm_free.
 *
 * NOTE TO STUDENTS: Replace this header comment with your own header
 * comment that gives a high level description of your solution.
 */
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>

#include "mm.h"
#include "memlib.h"

/*********************************************************
 * NOTE TO STUDENTS: Before you do anything else, please
 * provide your information in the following struct.
 ********************************************************/
team_t team = {
    /* Your student ID */
    "20181687",
    /* Your full name*/
    "Jiseok Jeong",
    /* Your email address */
    "jiseok99@hanmail.net",
};

/* single word (4) or double word (8) alignment */
#define ALIGNMENT 8

/* rounds up to the nearest multiple of ALIGNMENT */
#define ALIGN(size) (((size) + (ALIGNMENT-1)) & ~0x7)

#define SIZE_T_SIZE (ALIGN(sizeof(size_t)))
#define WSIZE 4                                                                             
#define DSIZE 8                                                                            
#define CHUNKSIZE  16                                                                     
#define OVERHEAD 24                                                                                                                   
#define PACK(size, alloc)  ((size) | (alloc))                                                                                                         
#define PUT(p, value)  (*(size_t *)(p) = (value))                                          
#define GET_SIZE(p)  ((*(size_t *)(p)) & ~0x7)                                                        
#define GET_ALLOC(p)  ((*(size_t *)(p)) & 0x1)                                                       
#define HDRP(ptr)  ((void *)(ptr) - WSIZE)                                                    
#define FTRP(ptr)  ((void *)(ptr) + GET_SIZE(HDRP(ptr)) - DSIZE)                               
#define NEXT_BLKP(ptr)  ((void *)(ptr) + GET_SIZE(HDRP(ptr)))                                  
#define PREV_BLKP(ptr)  ((void *)(ptr) - GET_SIZE(HDRP(ptr) - WSIZE))                          
#define NEXT_FREEP(ptr)  (*(void **)(ptr + DSIZE))                                            
#define PREV_FREEP(ptr)  (*(void **)(ptr))                                                   

static char *heap_listp;                                                                
static char *free_listp;                                                               

static void *extend_heap(size_t words);
static void place(void *ptr, size_t size);
static void *coalesce(void *ptr);
static void remove_block(void *ptr);

static void* extend_heap(size_t words){
    char *ptr;
    size_t size;

    size = (words % 2) ? (words + 1) * WSIZE : words * WSIZE;                              

    if(size < OVERHEAD)
        size = OVERHEAD;
        
    if((long)(ptr = mem_sbrk(size)) == -1)                                                  
        return NULL;
    
    PUT(HDRP(ptr), PACK(size, 0));                                                          
    PUT(FTRP(ptr), PACK(size, 0));                                                           
    PUT(HDRP(NEXT_BLKP(ptr)), PACK(0, 1));                                                  

    return coalesce(ptr);                                                                   
}

static void *coalesce(void *ptr){
    size_t prev_alloc = GET_ALLOC(FTRP(PREV_BLKP(ptr))) || PREV_BLKP(ptr) == ptr;          
    size_t next__alloc = GET_ALLOC(HDRP(NEXT_BLKP(ptr)));                                    
    size_t size = GET_SIZE(HDRP(ptr));                                                      

    if(prev_alloc && !next__alloc){                                                    
        size += GET_SIZE(HDRP(NEXT_BLKP(ptr)));                                             
        remove_block(NEXT_BLKP(ptr));                                                       
        PUT(HDRP(ptr), PACK(size, 0));                                                     
        PUT(FTRP(ptr), PACK(size, 0));                                                       
    }

    else if(!prev_alloc && next__alloc){                                                
        size += GET_SIZE(HDRP(PREV_BLKP(ptr)));                                             
        ptr = PREV_BLKP(ptr);                                                                 
        remove_block(ptr);                                                                 
        PUT(HDRP(ptr), PACK(size, 0));                                                      
        PUT(FTRP(ptr), PACK(size, 0));                                                       
    }

    else if(!prev_alloc && !next__alloc){                                               
        size += GET_SIZE(HDRP(PREV_BLKP(ptr))) + GET_SIZE(HDRP(NEXT_BLKP(ptr)));             
        remove_block(PREV_BLKP(ptr));                                                        
        remove_block(NEXT_BLKP(ptr));                                                      
        ptr = PREV_BLKP(ptr);                                                                
        PUT(HDRP(ptr), PACK(size, 0));                                                      
        PUT(FTRP(ptr), PACK(size, 0));                                                      
    }

    NEXT_FREEP(ptr) = free_listp;                                                            
    PREV_FREEP(free_listp) = ptr;                                                            
    PREV_FREEP(ptr) = NULL;                                                                  
    free_listp = ptr;    

    return ptr;
}

static void remove_block(void *ptr){
    if(PREV_FREEP(ptr))                                                                  
        NEXT_FREEP(PREV_FREEP(ptr)) = NEXT_FREEP(ptr);                                       
    else                                                                               
        free_listp = NEXT_FREEP(ptr);                                                        

    PREV_FREEP(NEXT_FREEP(ptr)) = PREV_FREEP(ptr);                                            
}

static void place(void *ptr, size_t size){
    size_t total_size = GET_SIZE(HDRP(ptr));                                                 

    if((total_size - size) >= OVERHEAD){                                                    
        PUT(HDRP(ptr), PACK(size, 1));                                                      
        PUT(FTRP(ptr), PACK(size, 1));                                                      
        remove_block(ptr);

        ptr = NEXT_BLKP(ptr);                                                                
        PUT(HDRP(ptr), PACK(total_size - size, 0));                                         
        PUT(FTRP(ptr), PACK(total_size - size, 0));                                          
        coalesce(ptr);                                                                       
    }

    else{                                                                                  
        PUT(HDRP(ptr), PACK(total_size, 1));                                                 
        PUT(FTRP(ptr), PACK(total_size, 1));                                                 
        remove_block(ptr);                                                                  
    }
}

/* 
 * mm_init - initialize the malloc package.
 */
int mm_init(void)
{
    
   if((heap_listp = mem_sbrk(2 * OVERHEAD)) == NULL)                                    
        return -1;

    PUT(heap_listp, 0); 
    PUT(heap_listp + (1*WSIZE), PACK(DSIZE, 1)); 
    PUT(heap_listp + (2*WSIZE), PACK(DSIZE, 1)); 
    PUT(heap_listp + (3*WSIZE), PACK(0, 1));
    heap_listp += (2*WSIZE);                                       
    free_listp = heap_listp + DSIZE;                                                      

    if(extend_heap(CHUNKSIZE / WSIZE) == NULL)                                         
        return -1;

    return 0;
}

/* 
 * mm_malloc - Allocate a block by incrementing the brk pointer.
 *     Always allocate a block whose size is a multiple of the alignment.
 */
void *mm_malloc(size_t size)
{
    size_t adj_size;                                                                  
    size_t extd_size;                                                                    
    char *bp;                                                                               

    if(size <= 0)                                                                       
        return NULL;

    if(ALIGN(size) + DSIZE > OVERHEAD)
        adj_size = ALIGN(size) + DSIZE;
    else
        adj_size = OVERHEAD;

    void *ptr = free_listp;
    void *check = NULL;
    
    while( GET_ALLOC(HDRP(ptr)) == 0) {                  
        if(adj_size <= GET_SIZE(HDRP(ptr))) {                                               
            check =  ptr;     
            break; 
        }
        ptr = NEXT_FREEP(ptr);                                 
    }                                      
                        
    if((bp = check)){                                                      
        place(bp, adj_size);                                                           
        return bp;
    }

    if(adj_size > CHUNKSIZE)
        extd_size = adj_size;
    else
        extd_size = CHUNKSIZE;                                           

    if((bp = extend_heap(extd_size / WSIZE)) == NULL)                                
        return NULL;                                                                       

    place(bp, adj_size);                                                               
    return bp;
}

/*
 * mm_free - Freeing a block does nothing.
 */
void mm_free(void *ptr)
{
    if(ptr == 0)                                                                               
        return;                                                                             

    size_t size = GET_SIZE(HDRP(ptr));                                                      

    PUT(HDRP(ptr), PACK(size, 0));                                                          
    PUT(FTRP(ptr), PACK(size, 0));                                                          
    coalesce(ptr); 
}

/*
 * mm_realloc - Implemented simply in terms of mm_malloc and mm_free
 */
void *mm_realloc(void *ptr, size_t size)
{    
    size_t adj_size;        
    if(ALIGN(size) + DSIZE > OVERHEAD)
        adj_size = ALIGN(size) + DSIZE;
    else
        adj_size = OVERHEAD;                                                                                           

    if(size == 0){                                                                          
        mm_free(ptr);                                                                       
        return 0;
    }

    if(ptr == NULL)                                                                         
        return mm_malloc(size);

    size_t cur_size; 
    cur_size = GET_SIZE(HDRP(ptr));                                                          

    if(adj_size == cur_size)                                                           
        return ptr;
    
    if(adj_size <= cur_size){                                                            
        size = adj_size;                                                                

        if(cur_size - size <= OVERHEAD)                                                     
            return ptr;                                                                     
                                                                                            
        PUT(HDRP(ptr), PACK(size, 1));                                                       
        PUT(FTRP(ptr), PACK(size, 1));                                                     
        PUT(HDRP(NEXT_BLKP(ptr)), PACK(cur_size - size, 1));                                 
        mm_free(NEXT_BLKP(ptr));                                                           
        return ptr;
    }
                                                                                            
    void *new_ptr = mm_malloc(size);                                                               

    if(!new_ptr)                                                                           
        return 0;

    if(size < cur_size)
        cur_size = size;

    memcpy(new_ptr, ptr, cur_size);                                                             
    mm_free(ptr);     

    return new_ptr;
}
